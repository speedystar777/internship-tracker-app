# Instructions
Welcome to the internship tracker application instruction manual! We are excited for you to try out our program. Please follow the listed instructions for a smooth experience.
## Requirements
For the internship tracker application to run, please install the follow packages:
If you do not have OPAM installed already, please install. 
Instructions can be found at https://cs3110.github.io/textbook/chapters/preface/install.html
ANSITerminal: run `opam install ANSITerminal`
## Running the Program
Call `make tracker` to run the program in the command line.
The program has detailed instructions within on how to proceed. 